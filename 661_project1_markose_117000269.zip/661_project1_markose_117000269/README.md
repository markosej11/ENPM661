ENPM661: Planning for Autonomous Robots. Project 1

#### Instructions to run the program for solving 8 puzzle problem
1) file name : Project1_planning_markose_117000269

2) Recommended IDE: PyCharm
   Version of python : Python 3

3) Running Instructions:
   The program will ask the user to enter the initial state of the puzzle.
   initial state is to be entered row wise.
   once the puzzle has been solved the path to the goal node will be displayed in the program itself

4) Libraries imported :
   numpy

5) Results:
   Once the puzzle has been solved the path to the goal node will be displayed automatically 
   The program will generate a text file with all the visited nodes in Nodes.txt
   The program will also generate a text file with the path to the goal node in Nodepath.txt





